---
name: cd-ground-overlays
description: "Convert multi-page Sphere/Comcast/MasTec construction-drawing (CD) PDFs into a KMZ of named GroundOverlay tiles for Google Earth Pro. One overlay per SITE PLAN sheet, positioned at the correct lat/lon bounding box. Use whenever a user wants to turn CD pages into Google Earth raster overlays, georeference site plan sheets as PNG tiles, render each construction drawing page onto satellite imagery, or stitch a multi-PRM job folder into a combined ground-overlay KMZ. Triggers on 'convert these CDs to ground overlays', 'render each site plan as a KMZ', 'georeference each page of this construction PDF', 'turn the site plans into Google Earth overlays', or any request mentioning a CD/permit PDF and ground overlays / raster tiles. Handles single PDFs and JB[id]/PRM[id]/drawing.pdf folder structures. RASTER overlays of rendered pages; for VECTOR route lines use cd-route-stitcher; for one-page Sphere overview maps use pdf-to-kmz."
---

# CD Ground Overlays

## What this skill does

Takes a multi-page Sphere/Comcast/MasTec construction-drawing PDF (typically 18 to 60 pages: cover, vicinity, notes, legend, multiple SITE PLAN tile pages, typical details, traffic control plans) and produces a KMZ where each site plan sheet is a separate, named GroundOverlay positioned at the correct geographic bounding box on satellite imagery in Google Earth Pro.

Output KMZ contains:
- One `<GroundOverlay>` per qualifying site plan sheet, named "SITE PLAN - N (PDF page M)"
- High-resolution PNG of each page (default 300 DPI, ~5100x3300 pixels for 17"x11" landscape pages)
- `LatLonBox` with `north`/`south`/`east`/`west` and `rotation` (zero when the rendered image is north-up)
- Per-overlay description recording the anchor source, confidence (HIGH / MEDIUM / LOW), and any manual-adjustment notes

For multi-PRM job folders (`JB[id]/PRM[id]/drawing.pdf`), the skill processes each PRM independently and also emits a combined JB-level KMZ.

## When to use

Use whenever the user wants any of:
- A Google Earth file showing the construction drawing pages laid over satellite imagery
- One ground overlay per site plan sheet (raster, not vector)
- A KMZ that lets reviewers toggle individual sheets on/off
- Batch processing of every PRM PDF in a JB folder

Identifying signals in the source:
- Multi-page PDF with sheet titles like `SITE PLAN - 1`, `SITE PLAN - 2`
- `MATCH TO SITE PLAN - N` callouts on left/right page edges
- Red dashed/solid route over an aerial photograph
- One page typically embeds an explicit lat/lon next to the start address (e.g., `2237 E 250 N, PERU IN 46970   40.801166, -86.030433`); when present, this is the gold anchor

If the user wants the ROUTE drawn as polylines (vector) instead of the rendered pages as raster tiles, use `cd-route-stitcher` instead. The two skills are complementary; nothing prevents running both on the same PDF.

## Prerequisites

```bash
pip install pymupdf pillow --break-system-packages
```

No external geocoder is required. The skill anchors from embedded lat/lon stamps when available and chains route-endpoint match-line continuity for the remaining sheets.

## Workflow

The pipeline is one script. Pass a PDF or a JB folder path.

### Single-PDF mode

```bash
python scripts/build_overlays.py /path/to/drawing.pdf --output /path/to/output.kmz
```

The script:
1. Walks every page, classifies it as site plan or non-site (cover, vicinity, notes, legend, typical details, traffic control)
2. Renders each site plan page at 300 DPI with PDF rotation applied (so north points up in the image when the drawing is north-up, which is the common case)
3. Extracts the embedded `lat, lon` stamp on whichever page carries it (typically Sheet 1)
4. Extracts route polyline endpoints and `MATCH TO SITE PLAN - N` labels for chaining
5. Builds a per-page affine transform from PDF unrotated coords to (lat, lon)
6. Computes the four-corner lat/lon bounding box of each rendered PNG
7. Emits a KMZ with one named GroundOverlay per sheet

### Multi-PRM mode

When run against a folder, the skill auto-detects the `JB[id]/PRM[id]/*.pdf` layout:

```bash
python scripts/build_overlays.py /path/to/JB123 --multi-prm --combined
```

Per-PRM KMZs are written into each PRM folder, and a `JB[id]_combined_overlays.kmz` is written to the JB folder containing every overlay across every PRM.

### Manual anchors (optional, sub-2m accuracy)

If a PDF lacks an embedded `lat, lon` stamp, supply hand-geocoded anchors via JSON:

```json
{
  "page_5": {"x_pdf": 81.3, "y_pdf": 200.3, "lat": 40.801166, "lon": -86.030433}
}
```

Then run with `--manual-anchors anchors.json`. PDF coords are in the rotated page rect (look at the rendered PNG and use rendered_pixel * 72 / DPI to get x_pdf, then `x_pdf = page_h - (rendered_y_pixel * 72 / DPI)` for unrotated x; if you want the absolute easiest path, just supply two corner lat/lon points and let the script invert the transform).

## Coordinate conventions (why the rotation math matters)

These CD PDFs are stored as portrait `792 x 1224` pages with a `270` rotation flag (i.e., displayed landscape). When the drawing's north arrow points UP in the rendered (landscape) view:

| Geographic axis | Rendered direction | Direction in unrotated PDF coords |
|---|---|---|
| North | up | +x_pdf |
| East  | right | +y_pdf |
| South | down  | -x_pdf |
| West  | left  | -y_pdf |

So the per-page transform is:

```
north_offset_feet = (x_pdf - x_anchor) * (scale_ft_per_inch / 72)
east_offset_feet  = (y_pdf - y_anchor) * (scale_ft_per_inch / 72)
```

This is the opposite of the convention used by `cd-route-stitcher`'s `auto_georef.py`, which assumes north-up in unrotated PDF coords. Don't borrow that module's transform; use this skill's bundled `build_overlays.py` instead. If you see all the overlays clustered into a tiny patch instead of stretching along the road, the rotation handling is wrong.

For pages drawn with a different north orientation, override per-page with a `rotation_deg` in the manual anchors JSON and the script will rotate the GroundOverlay's `LatLonBox` accordingly.

## Tile chaining (when only one page has an embedded coord)

Site plans tile west-to-east along the route. Each page's right-edge route exit is geographically the same point as the next page's left-edge route entry. The script:

1. Finds the polyline endpoint with maximum `y_pdf` on page N (rendered-RIGHT edge route exit)
2. Finds the polyline endpoint with minimum `y_pdf` on page N+1 (rendered-LEFT edge route entry)
3. Sets the page N+1 anchor lat/lon to the geographic location of page N's exit endpoint
4. Marks page N+1 confidence as MEDIUM (errors compound through long chains)

If the chain produces visible drift on satellite imagery, supply a manual anchor for any drifted page and the chain re-locks from that anchor onward.

## Output structure

A typical output for a 7-sheet job:

```
output.kmz
├── doc.kml         (named overlays, descriptions with confidence + adjust notes)
└── images/
    ├── sheet_05.png
    ├── sheet_06.png
    ...
    └── sheet_11.png
```

In Google Earth Pro the user sees:

```
[Document name]
└── Site Plan Sheets (7)
    ├── SITE PLAN - 1 (PDF page 5)   [HIGH confidence]
    ├── SITE PLAN - 2 (PDF page 6)   [MEDIUM, chained]
    ...
    └── SITE PLAN - 7 (PDF page 11)  [MEDIUM, chained]
```

Each overlay's description carries:
- Anchor source (embedded / chained / manual)
- Confidence level
- Specific instructions for nudging if satellite imagery does not line up: "right-click the overlay -> Properties -> Location, and adjust corners"

## Quality bar by use case

- **Production engineering layout:** not the right tool. Get the source `.dwg` from the drafter and export from Civil 3D directly.
- **Permit submittal exhibit:** acceptable when paired with manual anchors per page and span-length validation.
- **Visualization, corridor planning, reviewer markup, legacy job cleanup:** acceptable with default single-anchor + chain workflow.

State this in any deliverable note: "Georeferenced from drawing for visualization; not for engineering layout."

## Adjacent-tile overlap

Adjacent overlays intentionally overlap by ~50 to 100 feet east-west because each page extends past its match line by the title-block strip on the right and a small margin on the left. The chained anchor aligns the route exit and entry points, so the title block of sheet N geographically sits over the empty left-margin of sheet N+1. This is correct and matches reviewer intuition; do not "fix" it by cropping the page or trimming the bounding box.

## Validated reference

Validated against `JB0002131511/PRM0001388160/jb0002131511 A(1) PERU UTILITIES ONLY 21 POLES (2).pdf`:

- 18 pages total, 7 site plans (pages 5 to 11), 11 non-site (1 to 4 and 12 to 18) correctly skipped
- Sheet 1 anchored from embedded `2237 E 250 N PERU IN 46970   40.801166, -86.030433`
- Resulting overlays span longitude `-86.0308` to `-86.0156` at latitude `~40.801` (about 1.3 km east-west along E 250 N), matching the actual job extent
- Each tile measures `~680 ft EW x ~440 ft NS` at 1" = 40' scale
- Sheets 3 and 7 show ~85 ft north-south drift relative to neighbors, traced to route-endpoint shift between pages; documented in their overlay descriptions for manual nudging

## Known limitations

- **Drawing scale assumption** defaults to `1" = 40'` (the MasTec/Comcast standard for these jobs). Override with `--scale-feet-per-inch` when the title block prints a different scale.
- **North-up assumption** holds for all common Sphere/MasTec drawings. Drawings with a rotated north arrow need a per-page `rotation_deg` in the manual anchors file.
- **Chain accuracy** degrades after 5+ hops without a re-anchor. For long jobs, supply at least one embedded or manual anchor every ~5 sheets.
- **PDF rotation flag** must be honored when rendering. The bundled script handles the common `270` rotation; pages with `0` or `180` rotation render correctly because PyMuPDF's `get_pixmap` applies rotation by default.
- **Title-block exclusion** for embedded coords assumes the title block is in the bottom-right ~25% of the rotated page. Drafters with title blocks elsewhere will not be detected; supply a manual anchor.

## Gotchas

- If overlays cluster into a tiny patch instead of spreading along the road, the geographic-axis rotation is off by 90 degrees. Verify the +x_pdf-is-north / +y_pdf-is-east convention above and that you are using this skill's `build_overlays.py`, not `cd-route-stitcher`'s `auto_georef.py`.
- If overlays land in the wrong neighborhood, the embedded anchor was misread or the manual anchor lat/lon has the wrong sign. Spot-check the seed coord on Google Maps before running the chain.
- If a sheet shows up rotated 90 degrees on satellite imagery, the page rotation flag was not applied at render time; force re-render with explicit rotation override.
- "Match line crosses page diagonally" jobs (rare) need manual anchors per sheet because the chain logic assumes left-edge entry / right-edge exit.

## Files

- `scripts/build_overlays.py` - main script; runs the entire pipeline. Self-contained: includes PDF parsing, page rendering, georeferencing, KMZ assembly, and multi-PRM orchestration.
