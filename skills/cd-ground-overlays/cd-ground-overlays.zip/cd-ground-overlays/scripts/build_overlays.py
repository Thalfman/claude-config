#!/usr/bin/env python3
"""build_overlays.py - Convert multi-page CD PDFs into KMZ ground overlays.

USAGE
    Single PDF:
        python build_overlays.py /path/to/drawing.pdf --output /path/to/out.kmz

    Whole JB folder (auto-detect PRM[id]/*.pdf children):
        python build_overlays.py /path/to/JB123 --multi-prm
        python build_overlays.py /path/to/JB123 --multi-prm --combined

    With manual anchors:
        python build_overlays.py /path/to/drawing.pdf \
            --manual-anchors anchors.json \
            --output out.kmz

    Override scale (default 1" = 40'):
        python build_overlays.py /path/to/drawing.pdf --scale-feet-per-inch 50

WHAT IT DOES
    1. Identifies SITE PLAN pages (skips cover, vicinity, notes, legend,
       typical details, traffic control plans).
    2. Renders each site plan to PNG at --dpi (default 300) with PDF rotation
       applied so north points up in the rendered image.
    3. Anchors each page from the embedded "lat, lon" stamp (gold) when present,
       chains route-endpoint match-line continuity for the rest.
    4. Computes per-page lat/lon bounding box (north/south/east/west) and emits
       a KMZ with one named GroundOverlay per sheet.

GEOGRAPHIC AXES (for 270-deg rotated, north-up rendered pages):
    +x_pdf (unrotated) -> NORTH (rendered up)
    +y_pdf (unrotated) -> EAST  (rendered right)
"""
import argparse
import json
import math
import re
import sys
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

import fitz  # PyMuPDF


# ----- Constants you may override per-job -----
DEFAULT_DPI = 300
DEFAULT_SCALE_FT_PER_INCH = 40.0
PT_PER_INCH = 72.0
FEET_PER_DEG_LAT = 364320.0


# ----- Page classification regexes (mirror cd-route-stitcher) -----
LATLON_RE = re.compile(r'(-?\d{1,2}\.\d{4,8})\s*,\s*(-?\d{1,3}\.\d{4,8})')
ADDRESS_RE = re.compile(
    r'\b(\d{1,6})\s+([NSEW]\s+)?([A-Z0-9][A-Z0-9 .]+?)\s*,\s*([A-Z][A-Z ]+?)\s*,\s*([A-Z]{2})\s+(\d{5})',
    re.IGNORECASE,
)
MATCH_LINE_RE = re.compile(
    r'MATCH(?:\s+(?:TO|LINE))?\s*[:\-]?\s*SITE\s*PLAN\s*[-#]?\s*(\d+)', re.IGNORECASE,
)
SHEET_NUM_RE = re.compile(r'(?:SHEET|SITE\s*PLAN)\s*[-#:]?\s*(\d+)', re.IGNORECASE)

# Route stroke red palette (pure red and dark red used by Civil 3D)
ROUTE_R_MIN, ROUTE_GB_MAX = 0.80, 0.20
ROUTE_W_MIN, ROUTE_W_MAX = 0.40, 1.10

# Title block exclusion for embedded latlon (bottom-right of rotated page)
TITLE_BLOCK_X_FRAC = 0.65
TITLE_BLOCK_Y_FRAC = 0.75


def feet_per_deg_lon(lat_deg):
    return FEET_PER_DEG_LAT * math.cos(math.radians(lat_deg))


def is_route_color(c):
    return c is not None and len(c) >= 3 and c[0] >= ROUTE_R_MIN and c[1] <= ROUTE_GB_MAX and c[2] <= ROUTE_GB_MAX


def is_route_width(w):
    return w is not None and ROUTE_W_MIN <= w <= ROUTE_W_MAX


def text_blocks(page):
    """Flat list of text spans with center positions (in unrotated PDF coords)."""
    out = []
    for blk in page.get_text("dict").get("blocks", []):
        if blk.get("type") != 0:
            continue
        for line in blk.get("lines", []):
            text = ""
            bbox = None
            for span in line.get("spans", []):
                text += span.get("text", "")
                b = span.get("bbox")
                if b:
                    if bbox is None:
                        bbox = list(b)
                    else:
                        bbox[0] = min(bbox[0], b[0])
                        bbox[1] = min(bbox[1], b[1])
                        bbox[2] = max(bbox[2], b[2])
                        bbox[3] = max(bbox[3], b[3])
            if text.strip() and bbox:
                out.append({
                    "text": text.strip(),
                    "x": (bbox[0] + bbox[2]) / 2,
                    "y": (bbox[1] + bbox[3]) / 2,
                })
    return out


def in_title_block(x, y, page_w, page_h):
    return x >= page_w * TITLE_BLOCK_X_FRAC and y >= page_h * TITLE_BLOCK_Y_FRAC


def extract_embedded_latlon(blocks, page_w, page_h):
    """Return (x_pdf, y_pdf, lat, lon) for the first US-range coord outside the title block."""
    for blk in blocks:
        if in_title_block(blk["x"], blk["y"], page_w, page_h):
            continue
        for m in LATLON_RE.finditer(blk["text"]):
            lat = float(m.group(1)); lon = float(m.group(2))
            if 24.0 <= lat <= 50.0 and -130.0 <= lon <= -65.0:
                return blk["x"], blk["y"], lat, lon
    return None


def extract_route_endpoints(page):
    """Return (entry_pdf, exit_pdf) where entry = lowest y_pdf endpoint, exit = highest y_pdf.

    These correspond to the rendered-LEFT and rendered-RIGHT route termini for
    270-degree rotated pages with north-up.
    """
    ymin, ymax = float("inf"), float("-inf")
    entry = exit_ = None
    for d in page.get_drawings():
        if d.get("type") not in ("s", "sf", "fs"):
            continue
        if not is_route_color(d.get("color")) or not is_route_width(d.get("width")):
            continue
        endpts = []
        for item in d.get("items", []):
            op = item[0]
            if op == "l":
                endpts += [(item[1].x, item[1].y), (item[2].x, item[2].y)]
            elif op == "c":
                endpts += [(item[1].x, item[1].y), (item[4].x, item[4].y)]
        for x, y in endpts:
            if y < ymin:
                ymin = y; entry = (x, y)
            if y > ymax:
                ymax = y; exit_ = (x, y)
    return entry, exit_


def is_site_plan(blocks, page_idx):
    if page_idx < 3:
        return False
    has_match = any(MATCH_LINE_RE.search(b["text"]) for b in blocks)
    if has_match:
        return True
    has_addr = any(ADDRESS_RE.search(b["text"]) for b in blocks)
    has_sheet = any(SHEET_NUM_RE.search(b["text"]) for b in blocks)
    return has_addr and has_sheet


# ----- Geographic transform (north-up rendered) -----
def pdf_to_latlon(x_pdf, y_pdf, anchor, scale_ft_per_inch):
    """Convert unrotated PDF coords to (lat, lon).

    For a 270-deg rotated, north-up rendered page:
        +x_pdf -> NORTH, +y_pdf -> EAST.
    Optional rotation_deg in anchor allows fine adjustment if the drawing's
    north arrow is not exactly aligned with the page edge.
    """
    fpp = scale_ft_per_inch / PT_PER_INCH
    lat0, lon0 = anchor["lat0"], anchor["lon0"]
    x0, y0 = anchor["x0"], anchor["y0"]
    north_ft = (x_pdf - x0) * fpp
    east_ft = (y_pdf - y0) * fpp
    rot = anchor.get("rotation_deg", 0.0)
    if rot:
        rad = math.radians(rot)
        nf = north_ft * math.cos(rad) - east_ft * math.sin(rad)
        ef = north_ft * math.sin(rad) + east_ft * math.cos(rad)
        north_ft, east_ft = nf, ef
    lat = lat0 + north_ft / FEET_PER_DEG_LAT
    lon = lon0 + east_ft / feet_per_deg_lon(lat0)
    return lat, lon


def page_corner_bounds(anchor, page_w_pdf, page_h_pdf, scale_ft_per_inch):
    """Return north/south/east/west of the rendered PNG corners.

    page_size from PyMuPDF's page.rect on a rotated page is the rotated rect
    (width=1224, height=792 for these jobs). Rendered PNG covers the full
    rotated rect; inverse-rotate each rendered corner to unrotated PDF coords:
        rendered TL (rx=0, ry=0)         <-> (page_h, 0)
        rendered TR (rx=W, ry=0)         <-> (page_h, page_w)
        rendered BL (rx=0, ry=H)         <-> (0, 0)
        rendered BR (rx=W, ry=H)         <-> (0, page_w)
    where W=page_w_pdf, H=page_h_pdf, page_h=page_w_pdf (rotated width).
    """
    corners = [
        (page_h_pdf, 0),
        (page_h_pdf, page_w_pdf),
        (0, 0),
        (0, page_w_pdf),
    ]
    lats, lons = [], []
    for x, y in corners:
        lat, lon = pdf_to_latlon(x, y, anchor, scale_ft_per_inch)
        lats.append(lat); lons.append(lon)
    return {"north": max(lats), "south": min(lats), "east": max(lons), "west": min(lons)}


# ----- Page processing -----
def process_pdf(pdf_path, dpi, scale_ft_per_inch, manual_anchors, image_dir, debug=False):
    """Process one PDF. Render site plans, build anchors, return overlay metadata list."""
    doc = fitz.open(str(pdf_path))
    image_dir = Path(image_dir); image_dir.mkdir(parents=True, exist_ok=True)

    # 1. Per-page extraction
    pages_meta = []
    for i, page in enumerate(doc):
        blocks = text_blocks(page)
        site = is_site_plan(blocks, i)
        meta = {
            "page_number": i + 1,
            "is_site": site,
            "page_size": [page.rect.width, page.rect.height],
            "rotation": page.rotation,
        }
        if site:
            meta["embedded"] = extract_embedded_latlon(blocks, page.rect.width, page.rect.height)
            meta["entry_pdf"], meta["exit_pdf"] = extract_route_endpoints(page)
        pages_meta.append(meta)

    # 2. Render site plans
    for m in pages_meta:
        if not m["is_site"]:
            continue
        n = m["page_number"]
        page = doc[n - 1]
        pix = page.get_pixmap(matrix=fitz.Matrix(dpi / PT_PER_INCH, dpi / PT_PER_INCH), alpha=False)
        m["image_path"] = image_dir / f"sheet_{n:02d}.png"
        pix.save(str(m["image_path"]))

    # 3. Build anchors
    site_pages = [m for m in pages_meta if m["is_site"]]
    site_pages.sort(key=lambda x: x["page_number"])
    anchors, notes = {}, {}
    prev_anchor = None
    prev_exit = None
    for m in site_pages:
        n = m["page_number"]
        anchor = None; note = ""
        # Manual anchor (highest priority)
        ma = manual_anchors.get(f"page_{n}") or manual_anchors.get(str(n))
        if ma and "lat" in ma and "lon" in ma:
            anchor = {
                "x0": ma.get("x_pdf", 0),
                "y0": ma.get("y_pdf", 0),
                "lat0": ma["lat"],
                "lon0": ma["lon"],
                "rotation_deg": ma.get("rotation_deg", 0.0),
            }
            note = (f"Manual anchor PDF ({anchor['x0']:.1f}, {anchor['y0']:.1f}) "
                    f"-> ({anchor['lat0']:.6f}, {anchor['lon0']:.6f}). Confidence: HIGH.")
        # Embedded latlon
        elif m["embedded"]:
            x, y, lat, lon = m["embedded"]
            anchor = {"x0": x, "y0": y, "lat0": lat, "lon0": lon, "rotation_deg": 0.0}
            note = (f"Embedded lat/lon stamp at PDF ({x:.1f}, {y:.1f}) -> ({lat:.6f}, {lon:.6f}). "
                    f"Confidence: HIGH. No manual adjustment expected.")
        # Chain
        elif prev_anchor and prev_exit:
            entry = m["entry_pdf"]
            if entry:
                ex_lat, ex_lon = pdf_to_latlon(prev_exit[0], prev_exit[1], prev_anchor, scale_ft_per_inch)
                anchor = {"x0": entry[0], "y0": entry[1], "lat0": ex_lat, "lon0": ex_lon,
                          "rotation_deg": prev_anchor.get("rotation_deg", 0.0)}
                note = (f"Chained from page {prev_anchor['_page']} route exit "
                        f"PDF ({prev_exit[0]:.1f}, {prev_exit[1]:.1f}) -> ({ex_lat:.6f}, {ex_lon:.6f}); "
                        f"aligned to page {n} route entry PDF ({entry[0]:.1f}, {entry[1]:.1f}). "
                        f"Confidence: MEDIUM (errors compound through chain). If satellite imagery does "
                        f"not line up, right-click the overlay -> Properties -> Location, adjust corners.")

        if anchor is None:
            note = ("NO ANCHOR available. Sheet placed at default position; "
                    "manual placement of all 4 corners required in Google Earth Pro. Confidence: LOW.")
            anchors[n] = None
        else:
            anchor["_page"] = n
            anchors[n] = anchor
            prev_anchor = anchor
            prev_exit = m["exit_pdf"]
        notes[n] = note
        if debug:
            print(f"  page {n}: {note}", file=sys.stderr)

    # 4. Compute bounds and assemble overlay records
    overlays = []
    fallback_lat, fallback_lon = 0.0, 0.0  # used only when anchor is None
    if any(a for a in anchors.values()):
        any_anchor = next(a for a in anchors.values() if a)
        fallback_lat, fallback_lon = any_anchor["lat0"], any_anchor["lon0"]

    for m in site_pages:
        n = m["page_number"]
        a = anchors.get(n)
        if a is None:
            # Best-guess: place a small box at the fallback
            bounds = {"north": fallback_lat + 0.001, "south": fallback_lat - 0.001,
                      "east": fallback_lon + 0.001, "west": fallback_lon - 0.001}
        else:
            bounds = page_corner_bounds(a, m["page_size"][0], m["page_size"][1], scale_ft_per_inch)
        sheet_label = n - 4  # SITE PLAN N typically equals page_number - 4
        overlays.append({
            "page": n,
            "sheet_label": sheet_label,
            "name": f"SITE PLAN - {sheet_label} (PDF page {n})",
            "description": notes[n],
            "image_path": m["image_path"],
            "north": bounds["north"], "south": bounds["south"],
            "east": bounds["east"], "west": bounds["west"],
            "rotation": 0.0,
        })
    doc.close()
    return overlays


# ----- KMZ assembly -----
def write_kmz(overlays, kmz_path, doc_name, doc_description, image_subdir="images"):
    kml_lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<kml xmlns="http://www.opengis.net/kml/2.2">',
        '<Document>',
        f'<name>{escape(doc_name)}</name>',
        f'<description><![CDATA[{doc_description}]]></description>',
        '<open>1</open>',
        '<Folder>',
        f'<name>Site Plan Sheets ({len(overlays)})</name>',
    ]
    for ov in overlays:
        img_name = Path(ov["image_path"]).name
        kml_lines += [
            '<GroundOverlay>',
            f'  <name>{escape(ov["name"])}</name>',
            f'  <description><![CDATA[{ov["description"]}]]></description>',
            '  <Icon>',
            f'    <href>{image_subdir}/{img_name}</href>',
            '    <viewBoundScale>0.75</viewBoundScale>',
            '  </Icon>',
            '  <LatLonBox>',
            f'    <north>{ov["north"]:.8f}</north>',
            f'    <south>{ov["south"]:.8f}</south>',
            f'    <east>{ov["east"]:.8f}</east>',
            f'    <west>{ov["west"]:.8f}</west>',
            f'    <rotation>{ov["rotation"]:.4f}</rotation>',
            '  </LatLonBox>',
            '</GroundOverlay>',
        ]
    kml_lines += ['</Folder>', '</Document>', '</kml>']
    kml_text = "\n".join(kml_lines)

    kmz_path = Path(kmz_path)
    kmz_path.parent.mkdir(parents=True, exist_ok=True)
    if kmz_path.exists():
        kmz_path.unlink()
    with zipfile.ZipFile(kmz_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('doc.kml', kml_text)
        for ov in overlays:
            zf.write(ov["image_path"], f"{image_subdir}/{Path(ov['image_path']).name}")
    return kmz_path


def write_combined_kmz(jb_overlays, kmz_path, jb_name):
    """Combine multiple PRMs' overlays into one KMZ, organized by PRM folder."""
    kml_lines = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<kml xmlns="http://www.opengis.net/kml/2.2">',
        '<Document>',
        f'<name>{escape(jb_name)} - Combined Site Plan Overlays</name>',
        f'<description><![CDATA[Combined ground overlays for all PRMs in {jb_name}.]]></description>',
        '<open>1</open>',
    ]
    image_paths = []
    for prm_name, ovs in jb_overlays:
        kml_lines += ['<Folder>', f'<name>{escape(prm_name)} ({len(ovs)} sheets)</name>']
        for ov in ovs:
            img_name = f"{prm_name}__{Path(ov['image_path']).name}"
            image_paths.append((ov["image_path"], img_name))
            kml_lines += [
                '<GroundOverlay>',
                f'  <name>{escape(prm_name)} - {escape(ov["name"])}</name>',
                f'  <description><![CDATA[{ov["description"]}]]></description>',
                '  <Icon>',
                f'    <href>images/{img_name}</href>',
                '    <viewBoundScale>0.75</viewBoundScale>',
                '  </Icon>',
                '  <LatLonBox>',
                f'    <north>{ov["north"]:.8f}</north>',
                f'    <south>{ov["south"]:.8f}</south>',
                f'    <east>{ov["east"]:.8f}</east>',
                f'    <west>{ov["west"]:.8f}</west>',
                f'    <rotation>{ov["rotation"]:.4f}</rotation>',
                '  </LatLonBox>',
                '</GroundOverlay>',
            ]
        kml_lines.append('</Folder>')
    kml_lines += ['</Document>', '</kml>']
    kml_text = "\n".join(kml_lines)

    kmz_path = Path(kmz_path)
    if kmz_path.exists():
        kmz_path.unlink()
    with zipfile.ZipFile(kmz_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('doc.kml', kml_text)
        for src, dest in image_paths:
            zf.write(src, f"images/{dest}")
    return kmz_path


# ----- Main entry -----
def find_prm_pdfs(jb_dir):
    """Walk a JB folder and yield (prm_name, pdf_path) for each PRM*/*.pdf child."""
    jb = Path(jb_dir)
    for prm in sorted(jb.iterdir()):
        if not prm.is_dir():
            continue
        if not re.match(r'(?i)PRM', prm.name):
            continue
        pdfs = sorted(prm.glob("*.pdf"))
        if not pdfs:
            continue
        # Take the first PDF; warn if multiple
        if len(pdfs) > 1:
            print(f"WARN: multiple PDFs in {prm}; using {pdfs[0].name}", file=sys.stderr)
        yield prm.name, pdfs[0]


def main():
    ap = argparse.ArgumentParser(
        description="Convert multi-page CD PDFs into per-sheet KMZ ground overlays.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    ap.add_argument("input_path", help="PDF path OR JB[id] directory containing PRM[id]/*.pdf")
    ap.add_argument("--output", help="Output KMZ path (single-PDF mode). Default: <input>_overlays.kmz")
    ap.add_argument("--multi-prm", action="store_true",
                    help="Treat input_path as a JB folder; emit one KMZ per PRM child")
    ap.add_argument("--combined", action="store_true",
                    help="With --multi-prm, also emit JB-level combined KMZ")
    ap.add_argument("--manual-anchors", help="Optional JSON with per-page manual anchors")
    ap.add_argument("--scale-feet-per-inch", type=float, default=DEFAULT_SCALE_FT_PER_INCH,
                    help=f"Drawing scale (default {DEFAULT_SCALE_FT_PER_INCH})")
    ap.add_argument("--dpi", type=int, default=DEFAULT_DPI,
                    help=f"Render DPI (default {DEFAULT_DPI})")
    ap.add_argument("--debug", action="store_true")
    args = ap.parse_args()

    manual = {}
    if args.manual_anchors:
        manual = json.loads(Path(args.manual_anchors).read_text())

    inp = Path(args.input_path)
    if args.multi_prm:
        if not inp.is_dir():
            sys.exit(f"--multi-prm requires a directory, got {inp}")
        jb_overlays = []
        for prm_name, pdf in find_prm_pdfs(inp):
            print(f"== Processing {prm_name}: {pdf.name} ==", file=sys.stderr)
            img_dir = pdf.parent / "_overlay_images"
            ovs = process_pdf(pdf, args.dpi, args.scale_feet_per_inch, manual, img_dir, args.debug)
            kmz_out = pdf.parent / f"{prm_name}_overlays.kmz"
            write_kmz(ovs, kmz_out,
                      doc_name=f"{inp.name} / {prm_name} - Site Plan Overlays",
                      doc_description=f"Ground overlays for {pdf.name}.")
            print(f"  -> {kmz_out} ({len(ovs)} overlays)", file=sys.stderr)
            jb_overlays.append((prm_name, ovs))
        if args.combined and jb_overlays:
            combined = inp / f"{inp.name}_combined_overlays.kmz"
            write_combined_kmz(jb_overlays, combined, jb_name=inp.name)
            print(f"== Combined KMZ -> {combined} ==", file=sys.stderr)
    else:
        if not inp.is_file():
            sys.exit(f"Single-PDF mode requires a file, got {inp}")
        out = Path(args.output) if args.output else inp.with_suffix("").with_name(inp.stem + "_overlays.kmz")
        img_dir = out.parent / f"{out.stem}_images"
        ovs = process_pdf(inp, args.dpi, args.scale_feet_per_inch, manual, img_dir, args.debug)
        write_kmz(ovs, out,
                  doc_name=f"{inp.stem} - Site Plan Overlays",
                  doc_description=f"Ground overlays for {inp.name}.")
        print(f"Wrote {out} ({len(ovs)} overlays)", file=sys.stderr)


if __name__ == "__main__":
    main()
